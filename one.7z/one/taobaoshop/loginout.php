<?php
header("content-type:text/html;charset=utf-8");         //设置编码
?>
<?php
	setcookie("admin_user",'',time()-1,'/');
	echo "正在退出...";
	echo "<meta http-equiv='refresh' content='2,url=index.php'>";
?>