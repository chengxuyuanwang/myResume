<?php
	define('URL','/one/taobaoshop/');

	if(empty($_COOKIE['admin_user'])){
		header('location:','index.php');
	}
?>