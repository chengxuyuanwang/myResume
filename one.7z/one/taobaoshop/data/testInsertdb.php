<?php

	//添加数据
	require "../extends/Model.class.php";
	define("HOST", "qdm219186491.my3w.com");
	define("USER", "qdm219186491");
	define("PASS", "wangzhen");
	define("DBNAME", "qdm219186491_db");
	$model=new Model("s_student");
	function testInsert(){
		global $model;
		for($i=0;$i<20;$i++){
			$product['st_name'] = '李四'.$i;
    		$product['st_age'] = 23;
    		$product['st_sex'] = '女';
    		$product["st_class"]="14软件一班";
			var_dump($product);
			$addResult = $model->add($product);
			echo $addResult."<br>";
		}
	}
	// testInsert();
?>

