<?php
define("HOST", "qdm219186491.my3w.com");
define("USER", "qdm219186491");
define("PASS", "wangzhen");
define("DBNAME", "qdm219186491_db");