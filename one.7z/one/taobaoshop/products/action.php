<?php

	if (empty($_GET["a"])) {
		header("Location:index.php");
		exit;
	}
	require "../extends/Model.class.php";
	require "../extends/config.php";
	 require "../initconfig.php";
	$model=new Model('s_student');
	switch ($_GET["a"]) {
		//删除
		case 'delete':
			$deleteResult = $model->delete($_GET["st_id"]);
			var_dump($deleteResult);
			if ($deleteResult>0) {
				echo "<script>alert('删除成功')</script>";
				echo "<script>location.href='index.php'</script>";
			}else{
				echo "<script>alert('删除失败 有可能是外键错误 或没有传递参数')</script>";
				// echo "<script>history.back()</script>";
			}
			break;
		//修改
		case 'edit':
	        if($model->save($_POST)>0){
	        	echo "<script>alert('修改成功')</script>";
				echo "<script>location.href='index.php'</script>";
	        }else {
	        	echo "<script>alert('修改失败')</script>";
				echo "<script>history.back()</script>";
	        }
	        break;

	    //添加
	     case 'st_add':
	    	require "../extends/Upload.class.php";
	    	$upload = new Upload();	    
	    		// 上传成功后 将信息写入到数据库中
	    		$stModel = new Model('s_student');
	    		$data = $_POST;
	    		if($stModel->add($data)>0){
	    			echo "<script>alert('添加成功')</script>";
	    			echo "<script>location.href='st_index.php?st_id=".$data['st_id']."'</script>";
	    		}else {
	    			
	    			echo "<script>alert('上传成功但是信息插入失败')</script>";
	    			echo "<script>history.back()</script>";
	    		}
	        break;
	 
			default:
			# code...
			break;
	}
	
?>